The recommendation sysren we built is using Rshiny. The shiny app is published on the https://shuoqiang.shinyapps.io/Yelp/. 
You are more than welcome to use it!
