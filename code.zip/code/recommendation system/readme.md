The file business_classification is about review data cleaning, classifying restaurant categories and creating tags.
