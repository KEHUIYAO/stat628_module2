# Star Prediction

The folder contains the python file for predicting. The bigram.py file is to find the phrase contained in the reviews. The DL.py is using the self-builded deep learning model with softmax layer
as final layer for classification. The DL_re.py is using the self-builded deep learning model with linear layer
as final layer for regression. DL_system.py is using the self-builded deep learning model to construct the anti click farming system in the final recommendation system.
